package com.hackaboss.estudianteDeProgramacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudianteDeProgramacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
