package com.hackaboss.estudianteDeProgramacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudianteDeProgramacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudianteDeProgramacionApplication.class, args);
	}

}
